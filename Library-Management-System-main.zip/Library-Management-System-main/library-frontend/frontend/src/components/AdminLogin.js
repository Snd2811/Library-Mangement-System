import React from 'react'

const AdminLogin = () => {
  return (
    <div>
      Admin Login
    </div>
  )
}

export default AdminLogin
